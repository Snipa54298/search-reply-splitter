# 发布候选说明

此目录和对应 ZIP 是独立发布候选包，尚未上传 GitHub。暂定仓库名 natural-reply-splitter。

上传时只上传本目录中的源码、示例、测试和文档，不上传原项目目录。包内未附真实聊天记录、账户号码、个人资料卡、登录配置、密钥、浏览器数据或模型。

## 许可证待所有者选择

当前没有附加开源许可证，也没有在 pyproject.toml 声明许可证。公开可见不等于授予他人自由复制修改的许可；正式以开源项目发布前，请所有者选定许可（例如 MIT）并添加 LICENSE。本说明不是许可证。

## 依赖

- Python 3.10+，标准库 re/dataclasses/urllib.parse/random/time 等。
- 运行时不需要安装其他 Python 包。
- 可选 pip 构建安装需要 setuptools>=61。
- 平台 SDK、联网搜索及 LLM 都由使用方自己接入；不是隐含必装依赖。

## 验证

运行 `python -m unittest discover -s tests -v` 和 `python examples/demo.py`。
测试不发真实消息，不联网，不访问生产存档。此次本地验证环境为 Python 3.14；声明的其他 Python 版本尚未逐版本实测。

通过 GitHub 网页上传源码时，应展开 ZIP 后上传目录内容，不要仅上传 ZIP 作为仓库唯一文件。ZIP 也可以作为后续 Release 附件。
