import unittest
from natural_reply import split_reply,Source,search_messages,send_in_order,DeliveryError

class Tests(unittest.TestCase):
    def test_short(self):self.assertEqual(split_reply('好呀！',casual=True),['好呀！'])
    def test_noncasual(self):self.assertEqual(split_reply('一段。另一段。'),['一段。另一段。'])
    def test_empty(self):self.assertEqual(split_reply(' '),[])
    def test_sentence(self):
        text='今天的事情终于做完了！接下来可以好好休息一下'
        parts=split_reply(text,casual=True)
        self.assertEqual(len(parts),2);self.assertEqual(''.join(parts),text)
    def test_period_preserved(self):self.assertEqual(split_reply('今天很开心。',casual=True),['今天很开心。'])
    def test_optin_period(self):self.assertEqual(split_reply('今天很开心。',casual=True,strip_periods=True),['今天很开心'])
    def test_protected(self):
        for s in ['版本3.5很好用','说明：https://example.com/a?b=1','他说“今天已经做完了！现在终于可以休息了”','参考（第一部分！第二部分）']:
            self.assertEqual(split_reply(s,casual=True),[s])
    def test_paragraph(self):
        parts=split_reply('今天终于完成任务了\n接下来可以休息一下\n明天再继续做其他事情',casual=True)
        self.assertEqual(len(parts),2)
    def test_comma_optin(self):
        text='今天终于忙完了，可以先休息一下，明天继续努力'
        self.assertEqual(split_reply(text,casual=True),[text])
        self.assertEqual(''.join(split_reply(text,casual=True,comma_fallback=True)),text)
        self.assertEqual(len(split_reply(text,casual=True,comma_fallback=True)),2)
    def test_dependent(self):
        text='如果明天下雨，我们就留在家里，等天晴再出门'
        self.assertEqual(split_reply(text,casual=True,comma_fallback=True),[text])
    def test_long(self):
        text='这是一段很长的内容。'*10
        self.assertEqual(split_reply(text,casual=True),[text])
    def test_search(self):
        body='1. 打开设置。\n2. 保存。 [1]'
        for before,after in [('', ''),('已查到资料',''),('','整理完毕'),('已查到资料','整理完毕')]:
            parts=search_messages(body,[Source('文档','https://example.com/a')],before=before,after=after)
            self.assertEqual(len(parts),1+bool(before)+bool(after))
            self.assertIn(body,parts[bool(before)]);self.assertIn('https://example.com/a',parts[bool(before)])
    def test_keep_indices(self):
        s=Source('文档','https://example.com/a')
        self.assertIn('[2]',search_messages('见[2]',[s,s])[0])
    def test_oversize(self):
        with self.assertRaises(ValueError):search_messages('步骤不能默默丢失',[],max_message_chars=3)
    def test_url(self):
        for u in ['file:///tmp/a','javascript:alert(1)','https://u:p@example.com']:
            with self.assertRaises(ValueError):search_messages('正文',[Source('文档',u)])
    def test_delivery(self):
        clock=[0.];calls=[];ranges=[]
        def uniform(a,b):ranges.append((a,b));return (a+b)/2
        def send(t):calls.append(t);return len(calls)
        result=send_in_order(['a','b','c'],send,clock=lambda:clock[0],sleep=lambda t:clock.__setitem__(0,clock[0]+t),uniform=uniform)
        self.assertEqual(result,[1,2,3]);self.assertEqual(calls,['a','b','c'])
        self.assertEqual(ranges,[(1.8,2.2),(.8,1.2),(.8,1.2)])
    def test_no_retry(self):
        calls=[]
        def send(t):
            calls.append(t)
            if t=='b':raise TimeoutError()
            return 1
        with self.assertRaises(DeliveryError) as exc:
            send_in_order(['a','b','c'],send,first_delay=(0,0),next_delay=(0,0))
        self.assertEqual(calls,['a','b']);self.assertEqual(exc.exception.acknowledged,[1])
    def test_cancel(self):
        with self.assertRaises(DeliveryError):send_in_order(['a'],lambda _:self.fail(),cancelled=lambda:True)
    def test_invalid_delay(self):
        for bounds in [(0,float('inf')),(0,float('nan')),(-1,1),(2,1)]:
            with self.assertRaises(ValueError):send_in_order(['a'],lambda _:1,first_delay=bounds)
    def test_missing_ack(self):
        with self.assertRaises(DeliveryError):send_in_order(['a'],lambda _:None,first_delay=(0,0))
if __name__=='__main__':unittest.main()
