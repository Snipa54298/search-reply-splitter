"""Offline demo: prints messages, never connects to an account."""
import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from natural_reply import Source,search_messages,split_reply
print('普通聊天：')
for part in split_reply('今天的事情终于做完了！接下来可以好好休息一下',casual=True):print(repr(part))
print('搜索回复（示例链接，不代表真实检索）：')
for part in search_messages('1. 打开设置。\n2. 选择对应项目。 [1]',[Source('示例资料','https://example.com/guide')],before='找到相关资料了，步骤如下：'):
    print('---\n'+part)
