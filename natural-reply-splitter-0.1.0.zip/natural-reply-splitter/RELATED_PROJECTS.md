# GitHub 相似实现

查阅日期：2026-10-28。以下对照来自当时的 README 和所列源文件，仓库后续可能变化，不是穷尽搜索。

| 项目 | 相似之处 | 与本包的区别 |
| --- | --- | --- |
| [Custom Segment Reply](https://github.com/LinJohn8/astrbot_plugin_custome_segment_reply) | 本地规则、标点优先级、短尾合并、发送延迟 | 依赖 AstrBot 宿主；规则更丰富。本包是独立 Python 库，额外提供正文与引用绑定的组合接口 |
| [AstrBot 智能分段](https://github.com/exynos967/astrbot_plugin_smart_segmentation) | 回复生成后分段、延迟补发 | 额外使用分段模型；本包不调用模型，保守保留原文 |
| [通到 QQ](https://github.com/Yuuyuko-uu/dsh-qq-bridge) | 按空行拆段、配置段间间隔 | 是 DSH/OneBot 完整桥接；本包只提供展示与时序函数，不实现 QQ 收发 |

核对文件：

- [Custom Segment main.py](https://github.com/LinJohn8/astrbot_plugin_custome_segment_reply/blob/main/main.py)，blob SHA `93b1e34784d4a8341b8f46cfdbd5020c5f9cd4e3`。
- [Smart Segmentation main.py](https://github.com/exynos967/astrbot_plugin_smart_segmentation/blob/main/main.py)，blob SHA `b7500890b4dd1a980daafedf3974de8ba8e91616`。
- [DSH lib/client.js](https://github.com/Yuuyuko-uu/dsh-qq-bridge/blob/main/lib/client.js)，blob SHA `421b6f0b64524d0092f9fae2fa04d28f01703cc2`，设置页描述按空行拆段及默认450毫秒间隔。

本包的定位是“小型、无模型调用、角色中立、正文与来源不分离”，不是功能最多的框架插件。
