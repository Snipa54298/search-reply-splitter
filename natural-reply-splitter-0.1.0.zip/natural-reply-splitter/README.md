# Natural Reply Splitter

一个独立、轻量的中文聊天消息展示组件：保守断句、搜索正文与来源组合、分段延迟发送。

**不含角色卡、俏皮话生成器、模型调用、搜索引擎、QQ 登录或真实发送客户端。** 上游模型决定内容和语气，本组件尽量保留原文。它不是安装到 DSH/AstrBot 就能自动运行的插件；需要宿主接入几个 Python 函数。

## 功能

- 闲聊最多两条：明确换行优先，其次完整句末；默认不按逗号强拆。
- 可选 `comma_fallback=True`：至少两个逗号时尝试平衡切分；避开部分条件句、因果句、列举句。只是启发式，不能保证语义判断正确。
- 短句不强拆，超过 `max_chars` 的长文保持整体；引号、括号、URL、代码等保守不拆。
- 默认保留句号、问号和感叹号；`strip_periods=True` 才去掉分段末尾的中文句号。不会主动追加语气词或改写事实。
- 搜索正文与来源列表保持同一条消息。调用者可传入已有的前置/后置文本，组合成 1～3 条；组件不生成这些文本。
- 首条默认等待 1.8～2.2 秒，取得回执后，后续每条再等待 0.8～1.2 秒。
- 发送异常即停止，不自动重发；取消可中断等待。

## 依赖与运行

Python 3.10+；运行时只有标准库，第三方运行依赖为零。直接下载源码即可运行：

```sh
python examples/demo.py
python -m unittest discover -s tests -v
```

可选安装到其他 Python 项目：

```sh
python -m pip install .
```

安装构建需要 setuptools>=61（pip 的隔离构建可能下载它），这不是运行依赖。包内没有模型、浏览器、Node.js、NapCat 或 AstrBot。

## 最小用法

```python
from natural_reply import split_reply, Source, search_messages

parts = split_reply("今天的事情终于做完了！接下来可以好好休息一下", casual=True)

messages = search_messages(
    "1. 打开设置。\n2. 选择对应项目。 [1]",
    [Source("示例资料", "https://example.com/guide")],
    before="找到相关资料了，步骤如下：",  # 可省略，由宿主提供，不会自动生成
)
```

示例链接仅用于演示，不是实际搜索结果。正文中的 `[1]` 必须由宿主对齐 `sources` 顺序。组件不重新排序或去重来源，以免改变现有引用含义。

```python
from natural_reply import send_in_order, DeliveryError

def my_sender(text):
    # 接入你自己的平台 API；等待确认后返回消息回执。
    # 这里仅演示接口，真正实现由宿主提供。
    raise NotImplementedError

# 完成 my_sender 后调用；不要原样启用未实现的示例。
# receipts = send_in_order(messages, my_sender)
```

`send_in_order` 是同步函数。异步机器人应在工作线程中调用，或自行适配异步发送。默认等待会阻塞当前线程；取消不能中断正在执行的宿主网络请求，网络超时由宿主配置。

## 边界

- 长搜索正文不强行按字数切开，避免破坏步骤、链接和引用。超过平台限制会抛出异常，不会默默截断；宿主应缩短正文、使用长消息或文件。
- 这里只检查链接形式，不验证网页内容、可信度或可访问性，也不访问链接。
- 延迟仅改善展示节奏，不保证规避任何平台风控。
- 超时可能意味着消息已成功发送；组件不重试，宿主需持久化发送状态并处理幂等、身份验证与恢复。
- 当前包是从项目中整理的通用适配版，并非原项目整个 QQ 桥接模块。没有私人资料、聊天记录和模型配置。

参见 [来源与差异](PROVENANCE.md)、[相似项目](RELATED_PROJECTS.md) 和 [发布说明](PUBLISHING.md)。
