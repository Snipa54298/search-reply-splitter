"""Conservative Chinese splitting, adapted from the project delivery rules."""
import re

def split_reply(text: str, *, casual: bool = False, comma_fallback: bool = False,
                strip_periods: bool = False, min_part: int = 6,
                max_chars: int = 50) -> list[str]:
    """At most two messages; paragraph > sentence ending > optional comma.

    Heuristics only. Preserve wording and punctuation by default.
    Long or structured content stays whole rather than being truncated.
    """
    if not isinstance(text,str):raise TypeError('text must be a string')
    if min_part<1 or max_chars<1:raise ValueError('length settings must be positive')
    if not text.strip():return []
    if not casual or len(text)>max_chars:return [text]
    if any(x in text for x in ('http','```','[CQ:','(',')','（','）','《','》','“','”','「','」','『','』','"',"'")):
        return [text]
    def clean(s):
        s=s.strip()
        return s.rstrip('。') if strip_periods else s
    def valid(start,end):
        return len(text[:start].strip())>=min_part and len(text[end:].strip())>=min_part
    def choose(matches):
        return min(matches,key=lambda m:abs(len(text[:m.start()].strip())-len(text[m.end():].strip())))
    paragraphs=[m for m in re.finditer(r'\r?\n\s*',text) if valid(m.start(),m.end())]
    if paragraphs:
        m=choose(paragraphs)
        return [clean(text[:m.start()]),clean(text[m.end():])]
    # ASCII dots are not boundaries: protect decimals and abbreviations.
    endings=[m for m in re.finditer(r'[。！？!?]+',text) if valid(m.end(),m.end())]
    if endings:
        m=choose(endings)
        return [clean(text[:m.end()]),clean(text[m.end():])]
    if comma_fallback and len(re.findall('[，,]',text))>=2:
        dependent=r'如果|只要|只有|除非|因为|虽然|即使|不是.+而是|一边|分别|比如|例如|包括'
        if not re.search(dependent,text):
            candidates=[m for m in re.finditer('[，,]',text) if valid(m.end(),m.end())]
            if candidates:
                m=choose(candidates)
                return [clean(text[:m.end()]),clean(text[m.end():])]
    return [clean(text)]
