"""Keep search evidence together; no browsing, persona prompts or fact checking."""
from dataclasses import dataclass
from urllib.parse import urlsplit

@dataclass(frozen=True)
class Source:
    title: str
    url: str

def search_messages(body: str, sources: list[Source], *, before: str = '',
                    after: str = '', max_message_chars: int = 4000) -> list[str]:
    """Host-provided messages + intact body/citations, at most three.

    Keep source order, even duplicates, so existing [n] indices stay valid.
    Oversized messages raise; no steps are silently discarded.
    """
    if not all(isinstance(s,str) for s in (body,before,after)):
        raise TypeError('body/before/after must be strings')
    if not body.strip():raise ValueError('body cannot be empty')
    if max_message_chars<1:raise ValueError('max_message_chars must be positive')
    lines=[]
    for index,source in enumerate(sources,1):
        if not isinstance(source,Source):raise TypeError('expected Source instances')
        parsed=urlsplit(source.url)
        if parsed.scheme not in ('http','https') or not parsed.hostname or parsed.username or parsed.password or any(c.isspace() for c in source.url):
            raise ValueError('source must be an HTTP(S) URL without credentials')
        title=' '.join(source.title.split())
        lines.append(f'[{index}] {title}\n{source.url}')
    middle=body.strip()+('\n\n参考来源：\n'+'\n'.join(lines) if lines else '')
    parts=[s.strip() for s in (before,middle,after) if s.strip()]
    if any(len(s)>max_message_chars for s in parts):
        raise ValueError('message exceeds limit; shorten upstream or send a file')
    return parts
