"""Transport-independent formatting; no model or account configuration."""
from .splitter import split_reply
from .search import Source, search_messages
from .delivery import send_in_order, DeliveryError
__all__ = ['split_reply', 'Source', 'search_messages', 'send_in_order', 'DeliveryError']
