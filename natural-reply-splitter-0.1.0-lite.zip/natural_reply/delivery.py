"""Sequential acknowledgment-based delivery; cancellation, no automatic retry."""
import math
import random
import time

class DeliveryError(RuntimeError):
    def __init__(self,index,acknowledged,cause):
        super().__init__(f'delivery stopped at segment {index}; do not blindly resend')
        self.index=index
        self.acknowledged=list(acknowledged)
        self.cause=cause

def send_in_order(parts, send, *, cancelled=lambda: False, first_delay=(1.8,2.2),
                  next_delay=(.8,1.2), sleep=time.sleep, clock=time.monotonic,
                  uniform=random.uniform):
    """send(text) returns a non-None receipt only after acknowledgment.

    Host owns the chat client and durable recovery. A timeout can mean the
    message was delivered; this function never retries or resumes itself.
    """
    parts=list(parts)
    if not all(isinstance(p,str) and p.strip() for p in parts):
        raise ValueError('messages must be nonempty strings')
    for bounds in (first_delay,next_delay):
        if len(bounds)!=2 or not all(math.isfinite(v) for v in bounds) or not 0<=bounds[0]<=bounds[1]:
            raise ValueError('invalid delay interval')
    acknowledged=[]
    for index,part in enumerate(parts):
        try:
            deadline=clock()+uniform(*(first_delay if index==0 else next_delay))
            while True:
                if cancelled():raise RuntimeError('cancelled')
                remaining=deadline-clock()
                if remaining<=0:break
                sleep(min(.05,remaining))
            receipt=send(part)
            if receipt is None:raise RuntimeError('missing acknowledgment')
            acknowledged.append(receipt)
        except Exception as exc:
            raise DeliveryError(index,acknowledged,exc) from exc
    return acknowledged
